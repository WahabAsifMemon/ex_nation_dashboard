export const environment = {
  production: true,
  baseUrl:'http://jobtowners.com:3000/api/'
  // baseUrl:'http://localhost:3000/api/'  

};

