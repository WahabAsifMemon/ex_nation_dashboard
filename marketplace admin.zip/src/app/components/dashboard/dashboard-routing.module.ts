import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { HomeComponent } from './home/home.component';
import { LoginComponent } from 'src/app/auth/login/login.component';
import { TermsConditionComponent } from './terms-condition/terms-condition.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { SettingsComponent } from './settings/settings.component';
import { NotificationComponent } from './notification/notification.component';
import { HelpComponent } from './help/help.component';
import { HomeComponent } from './home/home.component';
import { FaqsComponent } from './faqs/faqs.component';
import { HowToUseComponent } from './how-to-use/how-to-use.component';
import { CandidateComponent } from './candidate/candidate.component';
import { EmployerComponent } from './employer/employer.component';
import { JobsComponent } from './jobs/jobs.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { CategoryComponent } from './category/category.component';
import { HomeCmsComponent } from './home-cms/home-cms.component';
import { MetaTagsComponent } from './meta-tags/meta-tags.component';




const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: 'home',
        component: HomeComponent,
      },
      {
        path: 'candidate',
        component: CandidateComponent,
      },

      {
        path: 'home-cms',
        component: HomeCmsComponent,
      },

      {
        path: 'employer',
        component: EmployerComponent,
      },

      {
        path: 'jobs',
        component: JobsComponent,
      },

      {
        path: 'faqs',
        component: FaqsComponent,
      },

      {
        path: 'terms&condition',
        component: TermsConditionComponent,
      },
      {
        path: 'privacy_policy',
        component: PrivacyPolicyComponent,
      },

      {
        path: 'notifications',
        component: NotificationComponent,
      },
      {
        path: 'settings',
        component: SettingsComponent,
      },

      {
        path: 'testimonials',
        component: TestimonialsComponent,
      },

      {
        path: 'category',
        component: CategoryComponent,
      },



      {
        path: 'helps',
        component: HelpComponent,
      },

      {
        path: 'how-to-use',
        component: HowToUseComponent,
      },


      {
        path: 'meta_tags',
        component: MetaTagsComponent,
      },






      // {
      //   path: 'package',
      //   component: PackageComponent,
      // },



      {
        path: '**',
        redirectTo: 'notifications',
      },
    ],
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class DashboardRoutingModule {}
