import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { HttpService } from 'src/app/shared/services/http.service';
import Swal from 'sweetalert2/dist/sweetalert2.js';


@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss']
})
export class HelpComponent {
  public Editor:any = ClassicEditor;
  public helpForm: any = this.fb.group({
    description: [null, Validators.required]
  });
  constructor(private fb:FormBuilder, private http:HttpService){

  }
  ngOnInit() {
    this.loadData();
  }
  async loadData() {
    await Promise.all([this.getHelp()]);
  }

  async getHelp() {
    try {
      const res: any = await this.http.get('get_help', true).toPromise();
      await this.helpForm.patchValue({
        description: res?.help,
      });
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }
  async save() {
    await this.http
      .post('create_help', this.helpForm.value, true)
      .subscribe((res: any) => {
        console.log(res);
        this.getHelp();
      });
  }
}
