import { Component } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { tap } from 'rxjs';
import { HttpService } from 'src/app/shared/services/http.service';

@Component({
  selector: 'app-testimonials',
  templateUrl: './testimonials.component.html',
  styleUrls: ['./testimonials.component.scss']
})
export class TestimonialsComponent {
  public Editor:any = ClassicEditor;
  public testimonials: [] = [];
  public duePage!: any;
  public total!: any;
  public searchInput!: any;
  public selectedTestimonial: any;
  public modalReference: any;
  public state: boolean = false;
  public testimonialForm: any = this.fb.group({
    client_name: [null, Validators.required],
    position: [null, Validators.required],
    company: [null, Validators.required],
    txt: [null, Validators.required],
    rating: [null, Validators.required],
    date: [null, Validators.required],
    type: [null, Validators.required],



  });
  constructor(
    private http: HttpService,
    private router: Router,
    private fb: FormBuilder,
    private modalService: NgbModal,
  ) {}
  userForm: any = this.fb.group({
    id: [null, Validators.required],
    status: [null, Validators.required],
  });
  ngOnInit() {
    this.loadData();
  }
  open(content: any, state: string) {
    this.modalReference = this.modalService.open(content, {
      centered: true,
      backdrop: 'static',
      windowClass: 'checkoutModal',
    });
    this.state = state == 'edit' ? true : false;
    if (state == 'edit') {
      const { id, client_name, position, company, txt, rating, date, type  } = this.selectedTestimonial || {};
      this.testimonialForm.addControl('id', new FormControl(id));
      this.testimonialForm.patchValue({
        ...this.testimonialForm.value,
        client_name,
        position,
        company,
        txt,
        rating,
        date,
        type
      });
    }
  }
  proceed() {
    this.modalReference.close();
    this.testimonialForm.reset();
    this.testimonialForm.removeControl('id');
    this.testimonialForm.removeControl('status');
    this.state = false;
  }
  async loadData() {
    await Promise.all([this.gettestimonials()]);
  }

  save(modal: boolean) {
    if (!this.state) {
      this.testimonialForm.patchValue({
        ...this.testimonialForm.value,
        position: this.testimonials?.length + 1,
      });
    }
    this.http
      .post('testimonial/create-testimonial', this.testimonialForm.value, true)

      .subscribe({
        next: () => {
          if (modal) {
            this.proceed();
          }
          this.testimonialForm.reset();
        },
        complete: () => {
          this.gettestimonials();
          this.testimonialForm.removeControl('id');
          this.testimonialForm.removeControl('status');
          this.state = false;
        },
      });
  }



  async gettestimonials() {
    try {
      const res: any = await this.http.get('testimonial/get-testimonial', true).toPromise();
      console.log(res);
        this.testimonials = res.testimonials;

    } catch (error) {
      console.error('Error fetching testimonials:', error);
    }
  }

  async stateItem(event: any, data: any) {
    this.selectedTestimonial = this.testimonials?.find((e: any) => e?.id == event.id);
    if (this.selectedTestimonial) {
      const { id, client_name, position, company, txt, rating, date, type } = this.selectedTestimonial || {};
      this.testimonialForm.patchValue({
        ...this.testimonialForm.value,
        client_name,
        position,
        company,
        txt,
        rating,
        date,
        type
      });

      this.testimonialForm.addControl('id', new FormControl(id));
      this.testimonialForm.addControl(
        'status',
        new FormControl(data.target.checked ? 1 : 0)
      );
      console.log(this.testimonialForm.value);
    }

    this.save(false);
  }

  deleteFaq(id: number) {
    this.http.post(`delete-faq/${id}`, {}, true).subscribe(
      () => {
        console.log(this.testimonialForm.value);
        this.gettestimonials();
      },
      (error) => {
        console.error('Error deleting video:', error);
      }
    );
  }


}
