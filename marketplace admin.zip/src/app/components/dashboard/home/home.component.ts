import { Component, OnInit } from '@angular/core';
import * as feather from 'feather-icons';
import { HttpService } from 'src/app/shared/services/http.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
})
export class HomeComponent implements OnInit {
  constructor(private http: HttpService) {}

  public users: number = 0;
  public jobs: number = 0;
  public history: number = 0;

  ngOnInit() {
    this.loadData();
    this.ngAfterViewInit();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      feather.replace();
    });
  }

  async loadData() {
    await Promise.all([this.getUsers(),]);
  }

  async getUsers() {
    try {
      const res: any = await this.http.get('auth/users', true).toPromise();
      console.log(res);
      this.users = res?.users?.length || 0;
    } catch (error) {
      console.error('Error fetching users:', error);
    }

    try {
      const res: any = await this.http.get('jobs/get_all_jobs', true).toPromise();
      console.log(res);
      this.jobs = res?.jobs?.length || 0;
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }

  // async getHistory() {
  //   try {
  //     const res: any = await this.http.get('get-post', true).toPromise();
  //     console.log(res);
  //     this.history = res?.Post?.length || 0;
  //   } catch (error) {
  //     console.error('Error fetching history:', error);
  //   }
  // }
}
