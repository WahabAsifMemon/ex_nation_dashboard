import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HttpService } from 'src/app/shared/services/http.service';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.scss']
})
export class UserDetailComponent {
  public user: any;
  job_apply: any[] = [];
  employer_jobs: any[] = [];
  candidate_job_apply:  any[] = [];
    public education: any;
  public experience: any;
  public postLength: number = 0;
  public duePage!: any;
  public total!: any;
  public searchInput!: any;
  public modalReference: any;

  constructor(private route: ActivatedRoute, private http: HttpService, private fb: FormBuilder, private modalService: NgbModal) {}

  ngOnInit() {
    this.route.params.subscribe(params => {
      let userId = params['id'];
      this.loadData(userId)
    });
  }

  async loadData(id: any) {
    await Promise.all([this.getUser(id)]);
  }

  async getUser(id: any) {
    try {
      const res: any = await this.http.get(`auth/user-by-id/?id=${id}`, true).toPromise();
      this.user = res?.user;
      this.job_apply = res.user.job_apply || [];  // Ensure it's an array
      this.candidate_job_apply = res.user.job_apply || [];



      this.education = res?.user?.employee_education;
      this.experience = res?.user?.candidate_experience;


      console.log(res);
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }

  proceed() {
    this.modalReference.close();
  }

  open(content: any, state: string) {
    this.modalReference = this.modalService.open(content, {
      centered: true,
      backdrop: 'static',
      windowClass: 'checkoutModal',
    });
  }
}
