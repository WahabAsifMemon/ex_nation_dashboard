(window as any).global = window;
import 'web-animations-js'; 

import 'zone.js';  
