import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpService } from 'src/app/shared/services/http.service';

@Component({
  selector: 'app-jobs',
  templateUrl: './jobs.component.html',
  styleUrls: ['./jobs.component.scss']
})
export class JobsComponent {
  public jobs: [] = [];
  public duePage!: any;
  public total!: any;
  public searchInput!: any;
  constructor(
    private http: HttpService,
    private router: Router,
    private fb: FormBuilder
  ) {}
  userForm: any = this.fb.group({
    id: [null, Validators.required],
    active_status: [null, Validators.required],
  });
  ngOnInit() {
    this.loadData();
      
  }
  async loadData() {
    await Promise.all([this.getJobs()]);
  }

  async getJobs() {
    try {
      const res: any = await this.http.get('jobs/get_all_jobs', true).toPromise();
      console.log(res, 'Hello');
      this.jobs = res?.jobs;
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }
 


}
