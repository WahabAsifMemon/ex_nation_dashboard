import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { HttpService } from 'src/app/shared/services/http.service';

@Component({
  selector: 'app-how-to-use',
  templateUrl: './how-to-use.component.html',
  styleUrls: ['./how-to-use.component.scss']
})
export class HowToUseComponent {
  public Editor:any = ClassicEditor;
  public howtouseForm: any = this.fb.group({
    description: [null, Validators.required]
  });
  constructor(private fb:FormBuilder, private http:HttpService){

  }
  ngOnInit() {
    this.loadData();
  }
  async loadData() {
    await Promise.all([this.getHowToUse()]);
  }

  async getHowToUse() {
    try {
      const res: any = await this.http.get('get_how_to_use', true).toPromise();
      await this.howtouseForm.patchValue({
        description: res?.howtouse,
      });
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }
  async save() {
    await this.http
      .post('create_how_to_use', this.howtouseForm.value, true)
      .subscribe((res: any) => {
        console.log(res);
        this.getHowToUse();
      });
  }
}
