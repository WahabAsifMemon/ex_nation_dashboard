import { Component } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HelperService } from 'src/app/shared/services/helper.service';
import { HttpService } from 'src/app/shared/services/http.service';


@Component({
  selector: 'app-meta-tags',
  templateUrl: './meta-tags.component.html',
  styleUrls: ['./meta-tags.component.scss']
})
export class MetaTagsComponent {
  public Editor:any = ClassicEditor;
  public heading: string;
  public meta_tags: [] = [];
  public duePage!: any;
  public total!: any;
  public searchInput!: any;
  public selectedMeta: any;
  public modalReference: any;
  public state: boolean = false;
  public metaForm: any = this.fb.group({
    page_name: [null, Validators.required],
    meta_tags: [null, Validators.required],

  });

  constructor(
    private http: HttpService,
    private router: Router,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private helper: HelperService,
    private route: ActivatedRoute,
  ) {}

  ngOnInit() {
    this.loadData();
    
  }

 

  open(content: any, state: string) {
    this.modalReference = this.modalService.open(content, {
      centered: true,
      backdrop: 'static',
      windowClass: 'checkoutModal',
    });
    this.state = state == 'edit' ? true : false;
    if (state == 'edit') {
      const { id, page_name, meta_tags,} = this.selectedMeta || {};
      this.metaForm.addControl('id', new FormControl(id));
      this.metaForm.patchValue({
        ...this.metaForm.value,
        page_name,
        meta_tags,
      });
    }
  }

  proceed() {
    this.modalReference.close();
    this.metaForm.reset();
    this.metaForm.removeControl('id');
    this.metaForm.removeControl('status');
    this.state = false;
  }

  async loadData() {
    await Promise.all([this.get_meta_tags()]);
  }

  save(modal: boolean) {
    this.http.post('cms/create-meta', this.metaForm.value, true).subscribe({
        next: () => {
            if (modal) {
                this.proceed(); 
            }
            this.metaForm.reset(); 
        },
        complete: () => {
            this.get_meta_tags();
            this.metaForm.removeControl('id');
            this.metaForm.removeControl('status');
            this.state = false;
        },
    });
}

  async get_meta_tags() {
    try {
      const res: any = await this.http.get('cms/get-meta', true).toPromise();
      this.meta_tags = res.meta;
    } catch (error) {
      console.error('Error fetching Meta data:', error);
    }
  }

  async stateItem(event: any, data: any) {
    this.selectedMeta = this.meta_tags?.find((e: any) => e?.id == event.id);
    if (this.selectedMeta) {
      const { id, page_name, meta_tags,   } = this.selectedMeta || {};
      this.metaForm.patchValue({
        ...this.metaForm.value,
        page_name,
        meta_tags,

      });
  
      this.metaForm.addControl('id', new FormControl(id));
      this.metaForm.addControl(
        'status',
        new FormControl(data.target.checked ? 1 : 0) 
      );
      console.log(this.metaForm.value);
    }
  
    this.save(false);
  }



  
}
