import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { NgbModule, NgbTooltipModule } from "@ng-bootstrap/ng-bootstrap";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { HomeComponent } from './home/home.component';
import { TermsConditionComponent } from './terms-condition/terms-condition.component';
import { PrivacyPolicyComponent } from './privacy-policy/privacy-policy.component';
import { CountToModule } from 'angular-count-to';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { NotificationComponent } from './notification/notification.component';
import { SettingsComponent } from './settings/settings.component';
import { ImageModule } from 'src/app/image/image.module';
import { NgxPaginationModule } from 'ngx-pagination';
import { HelpComponent } from './help/help.component';
import { FaqsComponent } from './faqs/faqs.component';
import { EllipsisModule } from '@thisissoon/angular-ellipsis';
import { HowToUseComponent } from './how-to-use/how-to-use.component';
import { CandidateComponent } from './candidate/candidate.component';
import { EmployerComponent } from './employer/employer.component';
import { JobsComponent } from './jobs/jobs.component';
import { TestimonialsComponent } from './testimonials/testimonials.component';
import { CategoryComponent } from './category/category.component';
import { HomeCmsComponent } from './home-cms/home-cms.component';
import { MetaTagsComponent } from './meta-tags/meta-tags.component';
@NgModule({
  declarations: [
    HomeComponent,
    TermsConditionComponent,
    PrivacyPolicyComponent,
    NotificationComponent,
    SettingsComponent,
    HelpComponent,
    FaqsComponent,
    HowToUseComponent,
    CandidateComponent,
    EmployerComponent,
    JobsComponent,
    TestimonialsComponent,
    CategoryComponent,
    HomeCmsComponent,
    MetaTagsComponent

    ],
  imports: [
    CommonModule,
    SharedModule,
    NgbModule,
    FormsModule,
    DashboardRoutingModule,
    CountToModule,
    ReactiveFormsModule,
    CKEditorModule,
    ImageModule,
    NgxPaginationModule,
    EllipsisModule,
    NgbTooltipModule
  ]
})
export class DashboardModule { }
