import { Component } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HelperService } from 'src/app/shared/services/helper.service';
import { HttpService } from 'src/app/shared/services/http.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent {
  public Editor:any = ClassicEditor;
  public categories: [] = [];
  public duePage!: any;
  public total!: any;
  public searchInput!: any;
  public selectedCategory: any;
  public modalReference: any;
  public state: boolean = false;
  public categoryForm: any = this.fb.group({
    title: [null, Validators.required],
    // icon_img: [null, Validators.required],
  });
  constructor(
    private http: HttpService,
    private router: Router,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private helper: HelperService,
  ) {}
  userForm: any = this.fb.group({
    id: [null, Validators.required],
    status: [null, Validators.required],
  });
  ngOnInit() {
    this.loadData();
  }
  open(content: any, state: string) {
    this.modalReference = this.modalService.open(content, {
      centered: true,
      backdrop: 'static',
      windowClass: 'checkoutModal',
    });
    this.state = state == 'edit' ? true : false;
    if (state == 'edit') {
      const { id, title, icon_img } = this.selectedCategory || {};
      this.categoryForm.addControl('id', new FormControl(id));
      this.categoryForm.patchValue({
        ...this.categoryForm.value,
        title,
        // icon_img,
      });
    }
  }
  proceed() {
    this.modalReference.close();
    this.categoryForm.reset();
    this.categoryForm.removeControl('id');
    this.categoryForm.removeControl('status');
    this.state = false;
  }
  async loadData() {
    await Promise.all([this.getCategory()]);
  }

  save(modal: boolean) {
    if (!this.state) {
      this.categoryForm.patchValue({
        ...this.categoryForm.value,
        position: this.categories?.length + 1,
      });
    }
    this.http
      .post('category/create_category', this.categoryForm.value, true)

      .subscribe({
        next: () => {
          if (modal) {
            this.proceed();
          }
          this.categoryForm.reset();
        },
        complete: () => {
          this.getCategory();
          this.categoryForm.removeControl('id');
          this.categoryForm.removeControl('status');
          this.state = false;
        },
      });
  }



  async getCategory() {
    try {
      const res: any = await this.http.get('category/get_category', true).toPromise();
      console.log(res);
      this.categories = res?.categories;
    } catch (error) {
      console.error('Error fetching users:', error);
    }
  }

  async stateItem(event: any, data: any) {
    this.selectedCategory = this.categories?.find((e: any) => e?.id == event.id);
    if (this.selectedCategory) {
      const { id, title, icon_img } = this.selectedCategory || {};
      this.categoryForm.patchValue({
        ...this.categoryForm.value,
        title,
        icon_img,
      });

      this.categoryForm.addControl('id', new FormControl(id));
      this.categoryForm.addControl(
        'status',
        new FormControl(data.target.checked ? 1 : 0)
      );
      console.log(this.categoryForm.value);
    }

    this.save(false);
  }

  deleteFaq(id: number) {
    this.http.post(`delete-faq/${id}`, {}, true).subscribe(
      () => {
        console.log(this.categoryForm.value);
        this.getCategory();
      },
      (error) => {
        console.error('Error deleting video:', error);
      }
    );
  }


  onImageSelected(event: any) {
    this.helper
      .fileUploadHttp(event)
      .then((result: any) => {
        this.categoryForm.patchValue({
          icon_img: result.data.image_url,
        });
        this.categoryForm.patchValue({
          ...this.categoryForm.value,
          icon_img: result.data.image_url,
        });
        console.log(this.categoryForm.value);
      })
      .catch((error) => {
        console.error(error);
      });
  }
}
