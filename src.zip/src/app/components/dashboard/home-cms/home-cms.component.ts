import { Component } from '@angular/core';
import { FormBuilder, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { HelperService } from 'src/app/shared/services/helper.service';
import { HttpService } from 'src/app/shared/services/http.service';

@Component({
  selector: 'app-home-cms',
  templateUrl: './home-cms.component.html',
  styleUrls: ['./home-cms.component.scss']
})
export class HomeCmsComponent {
  public Editor:any = ClassicEditor;
  public heading: string;
  public home_cms: [] = [];
  public duePage!: any;
  public total!: any;
  public searchInput!: any;
  public selectedCms: any;
  public modalReference: any;
  public state: boolean = false;
  public cmsForm: any = this.fb.group({
    page_name: ['', Validators.required],
    section_id: [null],
    heading: [null],
    sub_heading: [null],
    para: [null],
    image1: [null],
    image2: [null],
    image3: [null],
    image4: [null],
    image5: [null],

  });

  constructor(
    private http: HttpService,
    private router: Router,
    private fb: FormBuilder,
    private modalService: NgbModal,
    private helper: HelperService,
    private route: ActivatedRoute,
  ) {}

  ngOnInit() {
    this.loadData();
    
  }

  getPageNameFromParam(param: string): string {
    return param.replace('-', ' ');
  }

  open(content: any, state: string) {
    this.modalReference = this.modalService.open(content, {
      centered: true,
      backdrop: 'static',
      windowClass: 'checkoutModal',
    });
    this.state = state == 'edit' ? true : false;
    if (state == 'edit') {
      const { id, page_name, section_id, heading,  sub_heading, para,  image1, image2,  image3, image4, image5 } = this.selectedCms || {};
      this.cmsForm.addControl('id', new FormControl(id));
      this.cmsForm.patchValue({
        ...this.cmsForm.value,
        page_name,
        section_id,
        heading,
        sub_heading,
        para,
        image1,
        image2,
        image3,
        image4,
        image5,
      });
    }
  }

  proceed() {
    this.modalReference.close();
    this.cmsForm.reset();
    this.cmsForm.removeControl('id');
    this.cmsForm.removeControl('status');
    this.state = false;
  }

  async loadData() {
    await Promise.all([this.get_home_cms()]);
  }

  save(modal: boolean) {
    if (!this.state) {
        this.cmsForm.patchValue({
            ...this.cmsForm.value,
            position: this.home_cms?.length + 1,
            page_name: this.cmsForm.value.page_name || "Home" // Keep page_name persistent
        });
    }

    this.http.post('cms/create-cms', this.cmsForm.value, true).subscribe({
        next: () => {
            if (modal) {
                this.proceed(); 
            }
            
            const pageName = this.cmsForm.value.page_name; // Store page_name before reset
            this.cmsForm.reset(); 
            this.cmsForm.patchValue({ page_name: pageName }); // Restore page_name
        },
        complete: () => {
            this.get_home_cms();
            this.cmsForm.removeControl('id');
            this.cmsForm.removeControl('status');
            this.state = false;
        },
    });
}

  async get_home_cms() {
    try {
      const res: any = await this.http.get('cms/get-cms', true).toPromise();
      this.home_cms = res.cms;
    } catch (error) {
      console.error('Error fetching CMS data:', error);
    }
  }

  async stateItem(event: any, data: any) {
    this.selectedCms = this.home_cms?.find((e: any) => e?.id == event.id);
    if (this.selectedCms) {
      const { id, page_name, section_id, heading,  sub_heading, para,  image1, image2, image3, image4, image5  } = this.selectedCms || {};
      this.cmsForm.patchValue({
        ...this.cmsForm.value,
        page_name,
        section_id,
        heading,
        sub_heading,
        para,
        image1,
        image2,
        image3,
        image4,
        image5,

      });
  
      this.cmsForm.addControl('id', new FormControl(id));
      this.cmsForm.addControl(
        'status',
        new FormControl(data.target.checked ? 1 : 0) 
      );
      console.log(this.cmsForm.value);
    }
  
    this.save(false);
  }



  onImageOneSelected(event: any) {
    this.helper.fileUploadHttp(event)
      .then((result: any) => {
        this.cmsForm.patchValue({
          image1: result.data.image_url,
        });
        console.log(this.cmsForm.value);
      })
      .catch((error) => {
        console.error(error);
      });
  }

  onImageTwoSelected(event: any) {
    this.helper.fileUploadHttp(event)
      .then((result: any) => {
        this.cmsForm.patchValue({
          image2: result.data.image_url,
        });
        console.log(this.cmsForm.value);
      })
      .catch((error) => {
        console.error(error);
      });
  }




}
